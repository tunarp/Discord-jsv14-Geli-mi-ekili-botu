# 🎉 Discord.js v14 Çekiliş Botu

Bu proje, Discord.js v14 ile yazılmış kapsamlı ve profesyonel bir çekiliş botudur. Modern Discord özelliklerini kullanarak kullanıcı dostu bir deneyim sunar.

## ✨ Özellikler

### 🎯 Ana Özellikler
- **Slash Komut Desteği** - Modern Discord slash komutları
- **Buton ve Reaction Desteği** - İki farklı katılım yöntemi
- **Otomatik Çekiliş Yönetimi** - Zamanında otomatik sonlandırma
- **Çoklu Kazanan Desteği** - Birden fazla kazanan seçme
- **Detaylı Gereksinim Sistemi** - Rol, yaş ve katılım süresi kontrolleri
- **Kapsamlı Admin Paneli** - Bot yönetimi ve istatistikler
- **SQLite Veritabanı** - Hızlı ve güvenilir veri depolama
- **Gelişmiş Logging** - Detaylı log sistemi
- **Otomatik Yedekleme** - Veritabanı yedekleme sistemi

### 🛡️ Güvenlik ve Kontrol
- **Rol Gereksinimleri** - Belirli rollere sahip kullanıcılar katılabilir
- **Yasaklı Roller** - Belirli rollere sahip kullanıcılar katılamaz  
- **Minimum Hesap Yaşı** - Yeni hesapları engelleme
- **Minimum Sunucu Katılım Süresi** - Alt hesapları engelleme
- **Host Koruma** - Çekiliş sahibi kendi çekilişine katılamaz

### 📊 Yönetim Özellikleri
- **Çekiliş Listesi** - Sunucu çekilişlerini görüntüleme
- **Çekiliş Yeniden Çekme** - Kazananları yeniden belirleme
- **Çekiliş İptal Etme** - Aktif çekilişi iptal etme
- **Manuel Sonlandırma** - Çekiliş erken bitirme
- **Çekiliş Tamiri** - Bozuk çekilişleri onarma
- **İstatistikler** - Detaylı bot ve sunucu istatistikleri

## 🚀 Kurulum

### Gereksinimler
- Node.js v16.9.0 veya üstü
- Discord Bot Token
- SQLite desteği

### 1. Projeyi İndirin
```bash
git clone <repository-url>
cd cekilis-botu
```

### 2. Bağımlılıkları Yükleyin
```bash
npm install
```

### 3. Çevresel Değişkenleri Ayarlayın
`.env.example` dosyasını kopyalayıp `.env` olarak yeniden adlandırın:
```bash
cp .env.example .env
```

`.env` dosyasını düzenleyip gerekli değerleri girin:
```env
# Bot Token - Discord Developer Portal'dan alın
DISCORD_TOKEN=your_bot_token_here

# Bot ID - Botunuzun ID'si
BOT_ID=your_bot_id_here

# Guild ID (Sunucu ID) - Test için ana sunucunuz
GUILD_ID=your_guild_id_here

# Owner ID - Bot sahibinin Discord ID'si
OWNER_ID=your_user_id_here

# Database dosya yolu
DATABASE_PATH=./database/giveaways.db

# Log seviyesi (DEBUG, INFO, WARN, ERROR)
LOG_LEVEL=INFO
```

### 4. Botu Başlatın
```bash
# Geliştirme modu (otomatik yeniden başlatma)
npm run dev

# Üretim modu
npm start
```

## 🎮 Kullanım

### 🎉 Çekiliş Komutları

#### Çekiliş Oluşturma
```
/giveaway create prize:"Discord Nitro" duration:"1h" winners:1 title:"🎉 Nitro Çekilişi"
```

**Parametreler:**
- `prize` - Çekiliş ödülü (zorunlu)
- `duration` - Çekiliş süresi: `1m`, `1h`, `1d`, `1w` (zorunlu)
- `winners` - Kazanan sayısı (varsayılan: 1)
- `title` - Çekiliş başlığı (isteğe bağlı)
- `description` - Çekiliş açıklaması (isteğe bağlı)
- `channel` - Çekilişin yapılacağı kanal (isteğe bağlı)
- `emoji` - Çekiliş emojisi (varsayılan: 🎉)

#### Gereksinim Parametreleri
- `required_roles` - Gerekli roller (ID'leri virgülle ayırın)
- `blacklisted_roles` - Yasaklı roller (ID'leri virgülle ayırın)
- `min_account_age` - Minimum hesap yaşı (örn: `7d`, `1M`)
- `min_join_age` - Minimum sunucu katılım süresi (örn: `1d`, `1w`)

#### Diğer Çekiliş Komutları
```
/giveaway end message_id:123456789
/giveaway cancel message_id:123456789
/giveaway list status:active
/giveaway reroll message_id:123456789 winners:2
```

### ⚙️ Genel Komutlar
```
/help - Yardım menüsü
/ping - Bot gecikme süresi
/stats - Bot istatistikleri
```

### 🔧 Admin Komutları (Sadece Bot Sahibi)
```
/admin settings - Bot ayarlarını görüntüle
/admin database stats - Veritabanı istatistikleri
/admin database cleanup - Eski kayıtları temizle
/admin database backup - Veritabanı yedekle
/admin logs recent - Son logları göster
/admin system restart - Botu yeniden başlat
```

## 🏗️ Proje Yapısı

```
çekiliş botu/
├── src/
│   ├── commands/
│   │   ├── admin/
│   │   │   └── admin.js
│   │   ├── general/
│   │   │   ├── help.js
│   │   │   ├── ping.js
│   │   │   └── stats.js
│   │   └── giveaway/
│   │       └── create.js
│   ├── events/
│   │   ├── ready.js
│   │   ├── interactionCreate.js
│   │   ├── messageReactionAdd.js
│   │   └── messageReactionRemove.js
│   ├── managers/
│   │   └── GiveawayManager.js
│   ├── utils/
│   │   ├── Logger.js
│   │   └── Database.js
│   └── index.js
├── database/
│   └── giveaways.db
├── logs/
│   └── bot-YYYY-MM-DD.log
├── package.json
├── .env
├── .env.example
├── .gitignore
└── README.md
```

## 🗄️ Veritabanı Şeması

### `giveaways` Tablosu
```sql
CREATE TABLE giveaways (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT UNIQUE NOT NULL,
    channel_id TEXT NOT NULL,
    guild_id TEXT NOT NULL,
    host_id TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    prize TEXT NOT NULL,
    winners_count INTEGER DEFAULT 1,
    entries_count INTEGER DEFAULT 0,
    start_time INTEGER NOT NULL,
    end_time INTEGER NOT NULL,
    status TEXT DEFAULT 'active',
    requirements TEXT,
    emoji TEXT DEFAULT '🎉',
    created_at INTEGER DEFAULT (strftime('%s', 'now')),
    updated_at INTEGER DEFAULT (strftime('%s', 'now'))
);
```

### `participants` Tablosu
```sql
CREATE TABLE participants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    giveaway_id INTEGER NOT NULL,
    user_id TEXT NOT NULL,
    joined_at INTEGER DEFAULT (strftime('%s', 'now')),
    FOREIGN KEY (giveaway_id) REFERENCES giveaways (id) ON DELETE CASCADE,
    UNIQUE(giveaway_id, user_id)
);
```

### `winners` Tablosu
```sql
CREATE TABLE winners (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    giveaway_id INTEGER NOT NULL,
    user_id TEXT NOT NULL,
    position INTEGER NOT NULL,
    claimed BOOLEAN DEFAULT FALSE,
    claimed_at INTEGER,
    FOREIGN KEY (giveaway_id) REFERENCES giveaways (id) ON DELETE CASCADE
);
```

## 🎨 Özelleştirme

### Embed Renkleri
`.env` dosyasında hex renk kodlarını değiştirebilirsiniz:
```env
EMBED_COLOR_SUCCESS=0x00FF00
EMBED_COLOR_ERROR=0xFF0000
EMBED_COLOR_INFO=0x3498DB
EMBED_COLOR_WARNING=0xF39C12
```

### Emojiler
```env
GIVEAWAY_EMOJI=🎉
SUCCESS_EMOJI=✅
ERROR_EMOJI=❌
LOADING_EMOJI=⏳
```

## 📋 Geliştirme

### Yeni Komut Ekleme
1. `src/commands/kategori/komut.js` dosyası oluşturun
2. Komut yapısını takip edin:
```javascript
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('komut-adi')
        .setDescription('Komut açıklaması'),
    async execute(interaction, bot) {
        // Komut mantığı
    }
};
```

### Yeni Event Ekleme
1. `src/events/event-adi.js` dosyası oluşturun
2. Event yapısını takip edin:
```javascript
const { Events } = require('discord.js');

module.exports = {
    name: Events.EventName,
    once: false, // veya true
    async execute(arg1, arg2, bot) {
        // Event mantığı
    }
};
```

## 🐛 Hata Ayıklama

### Log Seviyeleri
- `DEBUG` - Tüm detayları göster
- `INFO` - Genel bilgileri göster (varsayılan)
- `WARN` - Uyarıları göster
- `ERROR` - Sadece hataları göster

### Log Dosyaları
Log dosyaları `logs/` klasöründe günlük olarak saklanır.

### Yaygın Hatalar

#### "Bot yanıt vermiyor"
- Bot token'ının doğru olduğundan emin olun
- Botun sunucuda ve gerekli izinlere sahip olduğundan emin olun
- Slash komutlarının deploy edildiğinden emin olun

#### "Veritabanı hatası"
- SQLite kurulu olduğundan emin olun
- Database klasörünün yazılabilir olduğundan emin olun
- `/admin database stats` komutunu kullanarak durumu kontrol edin

#### "Çekiliş görünmüyor"
- Botun mesaj gönderme izni olduğundan emin olun
- Embed gönderme izni olduğundan emin olun
- Reaction ekleme izni olduğundan emin olun

## 📄 Lisans

Bu proje MIT lisansı altında lisanslanmıştır ancak **ticari satışı kesinlikle yasaktır**.

**Önemli Lisans Notları:**
- ✅ **Ücretsiz kullanım** - Kişisel ve ticari olmayan projeler için özgürce kullanabilirsiniz
- ✅ **Düzenleme** - Kaynak kodunu istediğiniz gibi değiştirebilirsiniz
- ✅ **Dağıtım** - Ücretsiz olarak paylaşabilirsiniz
- ❌ **Satış Yasağı** - Bu botun satışı kesinlikle yasaktır
- 🔗 **Atıf** - Discord: syrox.dev atfı korunmalıdır

Detaylar için `LICENSE` dosyasını inceleyiniz.

### 🏷️ Geliştirici
**Geliştirilme:** Discord: syrox.dev tarafından geliştirilmiştir.

## 🤝 Katkıda Bulunma

1. Bu projeyi fork edin
2. Feature branch oluşturun (`git checkout -b feature/yeni-ozellik`)
3. Değişikliklerinizi commit edin (`git commit -am 'Yeni özellik: açıklama'`)
4. Branch'inizi push edin (`git push origin feature/yeni-ozellik`)
5. Pull Request oluşturun

## 📞 Destek

Herhangi bir sorun yaşarsanız:

1. Discord üzerinden syrox.dev hesabımdan yazabilirsiniz
2. Log dosyalarını ekleyin
3. Hatayı detaylandırın
4. Sistem bilgilerinizi paylaşın

## 🙏 Teşekkürler

- Discord.js ekibine harika kütüphane için
- SQLite ekibine güvenilir veritabanı için
- Discord topluluğuna sürekli destek için

---

**⚠️ Önemli Not:** Bu bot eğitim amaçlıdır. Üretim ortamında kullanmadan önce güvenlik kontrollerini yapmanız önerilir.

**Made with ❤️ for syrox.dev**