const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const commands = [];
const foldersPath = path.join(__dirname, 'src', 'commands');
const commandFolders = fs.readdirSync(foldersPath);

for (const folder of commandFolders) {
    const commandsPath = path.join(foldersPath, folder);
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    
    for (const file of commandFiles) {
        const filePath = path.join(commandsPath, file);
        const command = require(filePath);
        
        if ('data' in command && 'execute' in command) {
            commands.push(command.data.toJSON());
            console.log(`✅ ${command.data.name} komutu yüklendi`);
        } else {
            console.log(`⚠️ ${filePath} dosyasında eksik özellik var`);
        }
    }
}

const rest = new REST().setToken(process.env.DISCORD_TOKEN);

(async () => {
    try {
        console.log(`🔄 ${commands.length} slash komutu yenileniyor...`);

        // Guild-specific deployment (test için)
        if (process.env.GUILD_ID) {
            const data = await rest.put(
                Routes.applicationGuildCommands(process.env.BOT_ID, process.env.GUILD_ID),
                { body: commands },
            );
            console.log(`✅ ${data.length} slash komutu sunucuya başarıyla yüklendi!`);
        }

        // Global deployment (üretim için)
        // Uncomment the lines below for global deployment
        /*
        const data = await rest.put(
            Routes.applicationCommands(process.env.BOT_ID),
            { body: commands },
        );
        console.log(`✅ ${data.length} slash komutu global olarak yüklendi!`);
        */

    } catch (error) {
        console.error('❌ Komut yükleme hatası:', error);
        process.exit(1);
    }
})();