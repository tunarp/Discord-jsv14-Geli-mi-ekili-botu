const { Client, GatewayIntentBits, Collection } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const { Logger } = require('./utils/Logger');
const { Database } = require('./utils/Database');
const { GiveawayManager } = require('./managers/GiveawayManager');

class GiveawayBot {
    constructor() {
        this.client = new Client({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.GuildMessageReactions,
                GatewayIntentBits.MessageContent
            ]
        });

        this.logger = new Logger();
        this.database = new Database();
        this.giveawayManager = new GiveawayManager(this);
        
        // Command collection
        this.client.commands = new Collection();
        this.client.cooldowns = new Collection();
        
        this.init();
    }

    async init() {
        try {
            // Load events
            this.loadEvents();
            
            // Load commands
            this.loadCommands();
            
            // Initialize database
            await this.database.init();
            
            // Login to Discord
            await this.client.login(process.env.DISCORD_TOKEN);
            
        } catch (error) {
            this.logger.error('Bot başlatılırken hata:', error);
            process.exit(1);
        }
    }

    loadEvents() {
        const eventsPath = path.join(__dirname, 'events');
        if (!fs.existsSync(eventsPath)) return;

        const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

        for (const file of eventFiles) {
            const filePath = path.join(eventsPath, file);
            const event = require(filePath);
            
            if (event.once) {
                this.client.once(event.name, (...args) => event.execute(...args, this));
            } else {
                this.client.on(event.name, (...args) => event.execute(...args, this));
            }
            
            this.logger.info(`Event yüklendi: ${event.name}`);
        }
    }

    loadCommands() {
        const commandsPath = path.join(__dirname, 'commands');
        if (!fs.existsSync(commandsPath)) return;

        const commandFolders = fs.readdirSync(commandsPath);

        for (const folder of commandFolders) {
            const commandsFolder = path.join(commandsPath, folder);
            const commandFiles = fs.readdirSync(commandsFolder).filter(file => file.endsWith('.js'));

            for (const file of commandFiles) {
                const filePath = path.join(commandsFolder, file);
                const command = require(filePath);

                if ('data' in command && 'execute' in command) {
                    this.client.commands.set(command.data.name, command);
                    this.logger.info(`Komut yüklendi: ${command.data.name}`);
                } else {
                    this.logger.warn(`Komut dosyasında eksik özellik: ${filePath}`);
                }
            }
        }
    }

    async deployCommands() {
        const { REST, Routes } = require('discord.js');
        const commands = [];

        this.client.commands.forEach(command => {
            commands.push(command.data.toJSON());
        });

        const rest = new REST().setToken(process.env.DISCORD_TOKEN);

        try {
            this.logger.info('Slash komutları yenileniyor...');

            await rest.put(
                Routes.applicationGuildCommands(process.env.BOT_ID, process.env.GUILD_ID),
                { body: commands }
            );

            this.logger.success('Slash komutları başarıyla yenilendi!');
        } catch (error) {
            this.logger.error('Slash komutları yenilenirken hata:', error);
        }
    }
}

// Bot başlat
new GiveawayBot();

// Process error handlers
process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
    process.exit(1);
});