const { Events, Collection } = require('discord.js');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction, bot) {
        // Slash komut işlemleri
        if (interaction.isChatInputCommand()) {
            const command = interaction.client.commands.get(interaction.commandName);

            if (!command) {
                bot.logger.error(`${interaction.commandName} komutu bulunamadı!`);
                return;
            }

            // Cooldown kontrolü
            const { cooldowns } = interaction.client;

            if (!cooldowns.has(command.data.name)) {
                cooldowns.set(command.data.name, new Collection());
            }

            const now = Date.now();
            const timestamps = cooldowns.get(command.data.name);
            const defaultCooldownDuration = 3;
            const cooldownAmount = (command.cooldown ?? defaultCooldownDuration) * 1000;

            if (timestamps.has(interaction.user.id)) {
                const expirationTime = timestamps.get(interaction.user.id) + cooldownAmount;

                if (now < expirationTime) {
                    const expiredTimestamp = Math.round(expirationTime / 1000);
                    return interaction.reply({
                        content: `⏳ Lütfen bekleyiniz, bu komutu tekrar kullanabilmeniz için <t:${expiredTimestamp}:R> beklemelisiniz.`,
                        ephemeral: true,
                    });
                }
            }

            timestamps.set(interaction.user.id, now);
            setTimeout(() => timestamps.delete(interaction.user.id), cooldownAmount);

            // Komutu çalıştır
            try {
                bot.logger.logCommand(
                    interaction.guild?.name || 'DM',
                    interaction.user.tag,
                    interaction.commandName,
                    interaction.options?.data?.map(option => `${option.name}:${option.value}`) || []
                );

                await command.execute(interaction, bot);
            } catch (error) {
                bot.logger.error(`${interaction.commandName} komutu çalıştırılırken hata:`, error);
                
                const errorMessage = {
                    content: '❌ Bu komutu çalıştırırken bir hata oluştu!',
                    ephemeral: true,
                };

                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp(errorMessage);
                } else {
                    await interaction.reply(errorMessage);
                }
            }
        }
        // Buton etkileşimleri
        else if (interaction.isButton()) {
            try {
                if (interaction.customId.startsWith('giveaway_')) {
                    const action = interaction.customId.replace('giveaway_', '');
                    await bot.giveawayManager.handleParticipation(interaction, action);
                }
            } catch (error) {
                bot.logger.error('Buton etkileşimi işlenirken hata:', error);
                
                const errorMessage = {
                    content: '❌ Etkileşim işlenirken bir hata oluştu!',
                    ephemeral: true,
                };

                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp(errorMessage);
                } else {
                    await interaction.reply(errorMessage);
                }
            }
        }
        // Select menu etkileşimleri
        else if (interaction.isStringSelectMenu()) {
            try {
                // Gelecekte select menu'lar için kullanılabilir
                await interaction.reply({
                    content: '⚠️ Bu özellik henüz geliştirilmemiş!',
                    ephemeral: true
                });
            } catch (error) {
                bot.logger.error('Select menu etkileşimi işlenirken hata:', error);
            }
        }
        // Modal etkileşimleri
        else if (interaction.isModalSubmit()) {
            try {
                // Gelecekte modal'lar için kullanılabilir
                await interaction.reply({
                    content: '⚠️ Bu özellik henüz geliştirilmemiş!',
                    ephemeral: true
                });
            } catch (error) {
                bot.logger.error('Modal etkileşimi işlenirken hata:', error);
            }
        }
    },
};