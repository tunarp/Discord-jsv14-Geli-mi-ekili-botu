const { Events } = require('discord.js');

module.exports = {
    name: Events.MessageReactionAdd,
    async execute(reaction, user, bot) {
        // Bot'un kendi reaction'larını göz ardı et
        if (user.bot) return;

        // Partial reaction'ları fetch et
        if (reaction.partial) {
            try {
                await reaction.fetch();
            } catch (error) {
                bot.logger.error('Reaction fetch edilemedi:', error);
                return;
            }
        }

        try {
            const giveaway = bot.database.getGiveaway(reaction.message.id);
            
            if (!giveaway) return;
            
            // Çekiliş aktif değilse veya süresi dolmuşsa return
            if (giveaway.status !== 'active' || giveaway.end_time <= Math.floor(Date.now() / 1000)) {
                return;
            }

            // Doğru emoji mi kontrol et
            if (reaction.emoji.name !== giveaway.emoji) return;

            // Host kendi çekilişine katılamaz
            if (giveaway.host_id === user.id) {
                try {
                    await reaction.users.remove(user.id);
                } catch (error) {
                    bot.logger.error('Host reaction\'ı kaldırılamadı:', error);
                }
                return;
            }

            // Zaten katıldı mı kontrol et
            if (bot.database.isParticipant(giveaway.id, user.id)) return;

            // Üye bilgilerini al
            const guild = reaction.message.guild;
            const member = await guild.members.fetch(user.id).catch(() => null);
            
            if (!member) return;

            // Gereksinimleri kontrol et
            if (giveaway.requirements) {
                const requirements = JSON.parse(giveaway.requirements);
                const checkResult = await bot.giveawayManager.checkRequirements(member, requirements);
                
                if (!checkResult.passed) {
                    // Reaction'ı kaldır
                    try {
                        await reaction.users.remove(user.id);
                    } catch (error) {
                        bot.logger.error('Geçersiz kullanıcı reaction\'ı kaldırılamadı:', error);
                    }
                    
                    // Kullanıcıya DM gönder
                    try {
                        await user.send({
                            content: `❌ **${guild.name}** sunucusundaki **${giveaway.title}** çekilişine katılamazsınız!\n\n**Sebep:** ${checkResult.reason}`
                        });
                    } catch (error) {
                        // DM gönderilemezse sessizce devam et
                    }
                    return;
                }
            }

            // Katılımcıyı ekle
            const added = bot.database.addParticipant(giveaway.id, user.id);
            
            if (added) {
                // Mesajı güncelle
                await bot.giveawayManager.updateGiveawayMessage(reaction.message, giveaway.id);
                
                bot.logger.logGiveaway('katılım (reaction)', giveaway.id, {
                    user: user.tag,
                    userId: user.id
                });
            }

        } catch (error) {
            bot.logger.error('Reaction ekleme işlenirken hata:', error);
        }
    },
};