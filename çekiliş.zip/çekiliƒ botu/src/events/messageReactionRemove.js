const { Events } = require('discord.js');

module.exports = {
    name: Events.MessageReactionRemove,
    async execute(reaction, user, bot) {
        // Bot'un kendi reaction'larını göz ardı et
        if (user.bot) return;

        // Partial reaction'ları fetch et
        if (reaction.partial) {
            try {
                await reaction.fetch();
            } catch (error) {
                bot.logger.error('Reaction fetch edilemedi:', error);
                return;
            }
        }

        try {
            const giveaway = bot.database.getGiveaway(reaction.message.id);
            
            if (!giveaway) return;
            
            // Çekiliş aktif değilse return
            if (giveaway.status !== 'active') return;

            // Doğru emoji mi kontrol et
            if (reaction.emoji.name !== giveaway.emoji) return;

            // Katılımcı mı kontrol et
            if (!bot.database.isParticipant(giveaway.id, user.id)) return;

            // Katılımcıyı çıkar
            const removed = bot.database.removeParticipant(giveaway.id, user.id);
            
            if (removed) {
                // Mesajı güncelle
                await bot.giveawayManager.updateGiveawayMessage(reaction.message, giveaway.id);
                
                bot.logger.logGiveaway('ayrılma (reaction)', giveaway.id, {
                    user: user.tag,
                    userId: user.id
                });
            }

        } catch (error) {
            bot.logger.error('Reaction kaldırma işlenirken hata:', error);
        }
    },
};