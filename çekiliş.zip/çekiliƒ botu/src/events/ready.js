const { Events } = require('discord.js');

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client, bot) {
        bot.logger.success(`Bot ${client.user.tag} olarak giriş yaptı!`);
        bot.logger.info(`${client.guilds.cache.size} sunucuya hizmet veriliyor`);
        bot.logger.info(`${client.users.cache.size} kullanıcıya ulaşılabilir`);
        
        // Bot durumunu ayarla
        client.user.setActivity('🎉 Çekilişler | /help', {
            type: 'WATCHING'
        });

        // Slash komutları deploy et
        await bot.deployCommands();

        // Aktif çekilişlerin sayısını kontrol et
        const activeGiveaways = bot.database.getActiveGiveaways();
        bot.logger.info(`${activeGiveaways.length} aktif çekiliş bulundu`);

        // Veritabanı temizliği (eski kayıtları sil)
        const cleanupResult = bot.database.cleanup();
        if (cleanupResult.changes > 0) {
            bot.logger.info(`${cleanupResult.changes} eski çekiliş kaydı temizlendi`);
        }

        bot.logger.success('Bot başarıyla hazır!');
    }
};