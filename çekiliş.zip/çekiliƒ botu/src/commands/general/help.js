const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Bot komutları hakkında bilgi al')
        .addStringOption(option =>
            option.setName('command')
                .setDescription('Hakkında bilgi almak istediğin komut')
                .setRequired(false)
                .setAutocomplete(true)
        ),
    async execute(interaction, bot) {
        const commandName = interaction.options.getString('command');

        if (commandName) {
            // Belirli bir komut hakkında bilgi
            const command = interaction.client.commands.get(commandName);
            
            if (!command) {
                return await interaction.reply({
                    content: '❌ Bu komut bulunamadı!',
                    ephemeral: true
                });
            }

            const embed = new EmbedBuilder()
                .setTitle(`📖 ${command.data.name} Komutu`)
                .setDescription(command.data.description)
                .setColor(parseInt(process.env.EMBED_COLOR_INFO, 16) || 0x3498DB)
                .setTimestamp();

            // Alt komutları varsa ekle
            if (command.data.options && command.data.options.some(option => option.type === 1)) {
                const subcommands = command.data.options.filter(option => option.type === 1);
                let subcommandText = '';
                
                subcommands.forEach(sub => {
                    subcommandText += `**/${command.data.name} ${sub.name}** - ${sub.description}\n`;
                });
                
                embed.addFields({
                    name: 'Alt Komutlar',
                    value: subcommandText,
                    inline: false
                });
            }

            if (command.cooldown) {
                embed.addFields({
                    name: 'Cooldown',
                    value: `${command.cooldown} saniye`,
                    inline: true
                });
            }

            await interaction.reply({ embeds: [embed], ephemeral: true });
        } else {
            // Genel yardım sayfası
            const embed = new EmbedBuilder()
                .setTitle('🎉 Çekiliş Botu - Yardım')
                .setDescription(
                    'Merhaba! Ben bir çekiliş botuyum. Aşağıda mevcut komutlarımı bulabilirsiniz.\n\n' +
                    '**Komut kullanımı için `/` karakterini kullanın.**'
                )
                .setColor(parseInt(process.env.EMBED_COLOR_INFO, 16) || 0x3498DB)
                .setThumbnail(interaction.client.user.displayAvatarURL())
                .addFields(
                    {
                        name: '🎉 Çekiliş Komutları',
                        value: 
                            '`/giveaway create` - Yeni çekiliş oluştur\n' +
                            '`/giveaway end` - Çekiliş sonlandır\n' +
                            '`/giveaway cancel` - Çekiliş iptal et\n' +
                            '`/giveaway list` - Sunucu çekilişlerini listele\n' +
                            '`/giveaway reroll` - Kazananları yeniden seç',
                        inline: false
                    },
                    {
                        name: '⚙️ Genel Komutlar',
                        value: 
                            '`/help` - Bu yardım mesajını göster\n' +
                            '`/ping` - Bot gecikme süresini göster\n' +
                            '`/stats` - Bot istatistiklerini göster',
                        inline: false
                    },
                    {
                        name: '🔧 Admin Komutları',
                        value: 
                            '`/admin settings` - Bot ayarlarını yönet\n' +
                            '`/admin database` - Veritabanı yönetimi\n' +
                            '`/admin logs` - Log dosyalarını görüntüle',
                        inline: false
                    },
                    {
                        name: '📋 Çekiliş Özellikleri',
                        value: 
                            '• **Rol gereksinimleri** - Belirli rollere sahip kullanıcılar katılabilir\n' +
                            '• **Yasaklı roller** - Belirli rollere sahip kullanıcılar katılamaz\n' +
                            '• **Hesap yaşı kontrolü** - Minimum hesap yaşı belirleme\n' +
                            '• **Sunucu katılım süresi** - Minimum sunucu üyelik süresi\n' +
                            '• **Buton ve reaction desteği** - İki farklı katılım yöntemi\n' +
                            '• **Otomatik sonlandırma** - Çekilişler zamanında otomatik biter\n' +
                            '• **Çoklu kazanan** - Birden fazla kazanan seçilebilir',
                        inline: false
                    }
                )
                .setFooter({
                    text: `${interaction.guild.name} • Discord.js v14`,
                    iconURL: interaction.guild.iconURL()
                })
                .setTimestamp();

            await interaction.reply({ embeds: [embed], ephemeral: true });
        }
    },

    async autocomplete(interaction) {
        const focusedValue = interaction.options.getFocused();
        const choices = [
            'giveaway',
            'help',
            'ping',
            'stats',
            'admin'
        ];

        const filtered = choices.filter(choice => 
            choice.toLowerCase().includes(focusedValue.toLowerCase())
        );

        await interaction.respond(
            filtered.map(choice => ({ name: choice, value: choice })).slice(0, 25)
        );
    }
};