const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Bot gecikme süresini göster'),
    cooldown: 3,
    async execute(interaction, bot) {
        const sent = await interaction.reply({ 
            content: '🏓 Pong! Gecikme ölçülüyor...', 
            fetchReply: true,
            ephemeral: true 
        });

        const latency = sent.createdTimestamp - interaction.createdTimestamp;
        const apiLatency = Math.round(interaction.client.ws.ping);

        // Gecikme seviyesine göre renk belirle
        let color;
        if (apiLatency < 100) {
            color = parseInt(process.env.EMBED_COLOR_SUCCESS, 16) || 0x00FF00; // Yeşil
        } else if (apiLatency < 200) {
            color = parseInt(process.env.EMBED_COLOR_WARNING, 16) || 0xF39C12; // Sarı
        } else {
            color = parseInt(process.env.EMBED_COLOR_ERROR, 16) || 0xFF0000; // Kırmızı
        }

        // Gecikme seviyesine göre emoji
        let pingEmoji;
        if (apiLatency < 100) {
            pingEmoji = '🟢';
        } else if (apiLatency < 200) {
            pingEmoji = '🟡';
        } else {
            pingEmoji = '🔴';
        }

        const embed = new EmbedBuilder()
            .setTitle(`${pingEmoji} Pong!`)
            .setColor(color)
            .addFields(
                {
                    name: '📡 Bot Gecikmesi',
                    value: `\`${latency}ms\``,
                    inline: true
                },
                {
                    name: '💬 API Gecikmesi',
                    value: `\`${apiLatency}ms\``,
                    inline: true
                },
                {
                    name: '📊 Durum',
                    value: apiLatency < 100 ? 'Mükemmel' : 
                           apiLatency < 200 ? 'İyi' : 
                           apiLatency < 300 ? 'Orta' : 'Kötü',
                    inline: true
                }
            )
            .setFooter({
                text: `İstek sahibi: ${interaction.user.username}`,
                iconURL: interaction.user.displayAvatarURL()
            })
            .setTimestamp();

        await interaction.editReply({
            content: null,
            embeds: [embed]
        });
    }
};