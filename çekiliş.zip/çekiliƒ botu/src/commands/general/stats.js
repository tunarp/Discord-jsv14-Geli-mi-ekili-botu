const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const os = require('os');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('stats')
        .setDescription('Bot istatistiklerini göster'),
    cooldown: 5,
    async execute(interaction, bot) {
        await interaction.deferReply({ ephemeral: true });

        try {
            const client = interaction.client;
            
            // Bot istatistikleri
            const uptime = process.uptime();
            const days = Math.floor(uptime / 86400);
            const hours = Math.floor(uptime / 3600) % 24;
            const minutes = Math.floor(uptime / 60) % 60;
            const seconds = Math.floor(uptime % 60);
            
            const uptimeString = `${days}g ${hours}s ${minutes}d ${seconds}sn`;

            // Çekiliş istatistikleri
            const totalGiveaways = bot.database.db.prepare('SELECT COUNT(*) as count FROM giveaways').get().count;
            const activeGiveaways = bot.database.db.prepare('SELECT COUNT(*) as count FROM giveaways WHERE status = ?').get('active').count;
            const endedGiveaways = bot.database.db.prepare('SELECT COUNT(*) as count FROM giveaways WHERE status = ?').get('ended').count;
            const totalParticipants = bot.database.db.prepare('SELECT COUNT(*) as count FROM participants').get().count;
            const totalWinners = bot.database.db.prepare('SELECT COUNT(*) as count FROM winners').get().count;

            // Sunucu bazlı istatistikler
            const guildGiveaways = bot.database.db.prepare('SELECT COUNT(*) as count FROM giveaways WHERE guild_id = ?').get(interaction.guild.id).count;
            const guildActiveGiveaways = bot.database.db.prepare('SELECT COUNT(*) as count FROM giveaways WHERE guild_id = ? AND status = ?').get(interaction.guild.id, 'active').count;

            // Sistem istatistikleri
            const memUsage = process.memoryUsage();
            const totalMem = os.totalmem();
            const freeMem = os.freemem();
            const usedMem = totalMem - freeMem;

            const embed = new EmbedBuilder()
                .setTitle('📊 Bot İstatistikleri')
                .setColor(parseInt(process.env.EMBED_COLOR_INFO, 16) || 0x3498DB)
                .setThumbnail(client.user.displayAvatarURL())
                .addFields(
                    {
                        name: '🤖 Bot Bilgileri',
                        value: 
                            `**Bot Adı:** ${client.user.username}\n` +
                            `**Uptime:** ${uptimeString}\n` +
                            `**Ping:** ${client.ws.ping}ms\n` +
                            `**Discord.js:** v${require('discord.js').version}\n` +
                            `**Node.js:** ${process.version}`,
                        inline: true
                    },
                    {
                        name: '📈 Sunucu Bilgileri',
                        value: 
                            `**Sunucu Sayısı:** ${client.guilds.cache.size}\n` +
                            `**Kullanıcı Sayısı:** ${client.users.cache.size.toLocaleString()}\n` +
                            `**Kanal Sayısı:** ${client.channels.cache.size}\n` +
                            `**Komut Sayısı:** ${client.commands.size}`,
                        inline: true
                    },
                    {
                        name: '🎉 Global Çekiliş İstatistikleri',
                        value: 
                            `**Toplam Çekiliş:** ${totalGiveaways.toLocaleString()}\n` +
                            `**Aktif Çekiliş:** ${activeGiveaways.toLocaleString()}\n` +
                            `**Bitmiş Çekiliş:** ${endedGiveaways.toLocaleString()}\n` +
                            `**Toplam Katılım:** ${totalParticipants.toLocaleString()}\n` +
                            `**Toplam Kazanan:** ${totalWinners.toLocaleString()}`,
                        inline: true
                    },
                    {
                        name: '🏛️ Bu Sunucu İstatistikleri',
                        value: 
                            `**Toplam Çekiliş:** ${guildGiveaways.toLocaleString()}\n` +
                            `**Aktif Çekiliş:** ${guildActiveGiveaways.toLocaleString()}\n` +
                            `**Üye Sayısı:** ${interaction.guild.memberCount.toLocaleString()}\n` +
                            `**Boost Seviyesi:** ${interaction.guild.premiumTier}\n` +
                            `**Boost Sayısı:** ${interaction.guild.premiumSubscriptionCount || 0}`,
                        inline: true
                    },
                    {
                        name: '💾 Sistem Bilgileri',
                        value: 
                            `**Platform:** ${os.platform()}\n` +
                            `**CPU:** ${os.cpus()[0].model.split(' ')[0]} (${os.cpus().length} çekirdek)\n` +
                            `**RAM Kullanımı:** ${(memUsage.heapUsed / 1024 / 1024).toFixed(2)}MB\n` +
                            `**Sistem RAM:** ${(usedMem / 1024 / 1024 / 1024).toFixed(2)}GB / ${(totalMem / 1024 / 1024 / 1024).toFixed(2)}GB\n` +
                            `**Uptime:** ${(os.uptime() / 3600).toFixed(1)} saat`,
                        inline: true
                    }
                )
                .setFooter({
                    text: `İstek sahibi: ${interaction.user.username} • ${new Date().toLocaleString('tr-TR')}`,
                    iconURL: interaction.user.displayAvatarURL()
                })
                .setTimestamp();

            // En aktif sunucuları ekle (top 5)
            try {
                const topGuilds = bot.database.db.prepare(`
                    SELECT guild_id, COUNT(*) as giveaway_count 
                    FROM giveaways 
                    GROUP BY guild_id 
                    ORDER BY giveaway_count DESC 
                    LIMIT 5
                `).all();

                if (topGuilds.length > 0) {
                    let topGuildsText = '';
                    for (let i = 0; i < topGuilds.length; i++) {
                        const guildData = topGuilds[i];
                        const guild = client.guilds.cache.get(guildData.guild_id);
                        const guildName = guild ? guild.name : 'Bilinmeyen Sunucu';
                        topGuildsText += `${i + 1}. **${guildName}** - ${guildData.giveaway_count} çekiliş\n`;
                    }

                    embed.addFields({
                        name: '🏆 En Aktif Sunucular',
                        value: topGuildsText,
                        inline: false
                    });
                }
            } catch (error) {
                bot.logger.error('Top guilds alınırken hata:', error);
            }

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            bot.logger.error('Stats komutu çalıştırılırken hata:', error);
            await interaction.editReply({
                content: '❌ İstatistikler alınırken bir hata oluştu!'
            });
        }
    }
};