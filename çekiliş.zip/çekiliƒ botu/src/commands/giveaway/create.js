const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const ms = require('ms');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('giveaway')
        .setDescription('Çekiliş komutları')
        .addSubcommand(subcommand =>
            subcommand
                .setName('create')
                .setDescription('Yeni bir çekiliş oluştur')
                .addStringOption(option =>
                    option.setName('prize')
                        .setDescription('Çekiliş ödülü')
                        .setRequired(true)
                        .setMaxLength(256)
                )
                .addStringOption(option =>
                    option.setName('duration')
                        .setDescription('Çekiliş süresi (örn: 1h, 30m, 1d)')
                        .setRequired(true)
                )
                .addIntegerOption(option =>
                    option.setName('winners')
                        .setDescription('Kazanan sayısı')
                        .setRequired(false)
                        .setMinValue(1)
                        .setMaxValue(50)
                )
                .addStringOption(option =>
                    option.setName('title')
                        .setDescription('Çekiliş başlığı (varsayılan: "🎉 Çekiliş!")')
                        .setRequired(false)
                        .setMaxLength(256)
                )
                .addStringOption(option =>
                    option.setName('description')
                        .setDescription('Çekiliş açıklaması')
                        .setRequired(false)
                        .setMaxLength(1000)
                )
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('Çekilişin yapılacağı kanal (varsayılan: mevcut kanal)')
                        .setRequired(false)
                )
                .addStringOption(option =>
                    option.setName('emoji')
                        .setDescription('Çekiliş emojisi (varsayılan: 🎉)')
                        .setRequired(false)
                )
                .addStringOption(option =>
                    option.setName('required_roles')
                        .setDescription('Gerekli roller (ID\'leri virgülle ayırın)')
                        .setRequired(false)
                )
                .addStringOption(option =>
                    option.setName('blacklisted_roles')
                        .setDescription('Yasaklı roller (ID\'leri virgülle ayırın)')
                        .setRequired(false)
                )
                .addStringOption(option =>
                    option.setName('min_account_age')
                        .setDescription('Minimum hesap yaşı (örn: 7d, 1M)')
                        .setRequired(false)
                )
                .addStringOption(option =>
                    option.setName('min_join_age')
                        .setDescription('Minimum sunucu katılım süresi (örn: 1d, 1w)')
                        .setRequired(false)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('end')
                .setDescription('Çekiliş sonlandır')
                .addStringOption(option =>
                    option.setName('message_id')
                        .setDescription('Çekiliş mesaj ID\'si')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('cancel')
                .setDescription('Çekiliş iptal et')
                .addStringOption(option =>
                    option.setName('message_id')
                        .setDescription('Çekiliş mesaj ID\'si')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('Sunucudaki çekilişleri listele')
                .addStringOption(option =>
                    option.setName('status')
                        .setDescription('Çekiliş durumu')
                        .setRequired(false)
                        .addChoices(
                            { name: 'Aktif', value: 'active' },
                            { name: 'Bitmiş', value: 'ended' },
                            { name: 'İptal Edilmiş', value: 'cancelled' }
                        )
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('reroll')
                .setDescription('Çekiliş kazananlarını yeniden seç')
                .addStringOption(option =>
                    option.setName('message_id')
                        .setDescription('Çekiliş mesaj ID\'si')
                        .setRequired(true)
                )
                .addIntegerOption(option =>
                    option.setName('winners')
                        .setDescription('Yeni kazanan sayısı')
                        .setRequired(false)
                        .setMinValue(1)
                        .setMaxValue(50)
                )
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
    cooldown: 5,
    async execute(interaction, bot) {
        const subcommand = interaction.options.getSubcommand();

        switch (subcommand) {
            case 'create':
                await this.handleCreate(interaction, bot);
                break;
            case 'end':
                await this.handleEnd(interaction, bot);
                break;
            case 'cancel':
                await this.handleCancel(interaction, bot);
                break;
            case 'list':
                await this.handleList(interaction, bot);
                break;
            case 'reroll':
                await this.handleReroll(interaction, bot);
                break;
            default:
                await interaction.reply({
                    content: '❌ Bilinmeyen alt komut!',
                    ephemeral: true
                });
        }
    },

    async handleCreate(interaction, bot) {
        await interaction.deferReply({ ephemeral: true });

        try {
            const prize = interaction.options.getString('prize');
            const durationStr = interaction.options.getString('duration');
            const winnersCount = interaction.options.getInteger('winners') || 1;
            const title = interaction.options.getString('title') || '🎉 Çekiliş!';
            const description = interaction.options.getString('description');
            const channel = interaction.options.getChannel('channel') || interaction.channel;
            const emoji = interaction.options.getString('emoji') || '🎉';
            const requiredRoles = interaction.options.getString('required_roles');
            const blacklistedRoles = interaction.options.getString('blacklisted_roles');
            const minAccountAge = interaction.options.getString('min_account_age');
            const minJoinAge = interaction.options.getString('min_join_age');

            // Süre kontrolü
            const duration = ms(durationStr);
            if (!duration || duration < 60000) { // Minimum 1 dakika
                return await interaction.editReply({
                    content: '❌ Geçersiz süre! Minimum 1 dakika olmalı. (Örnek: 1m, 1h, 1d)'
                });
            }

            if (duration > 2592000000) { // Maksimum 30 gün
                return await interaction.editReply({
                    content: '❌ Maksimum çekiliş süresi 30 gündür!'
                });
            }

            // Kanal kontrolü
            if (!channel.isTextBased()) {
                return await interaction.editReply({
                    content: '❌ Sadece metin kanallarında çekiliş oluşturabilirsiniz!'
                });
            }

            // Emoji kontrolü
            const emojiRegex = /^(\p{Emoji}|\p{Emoji_Modifier}|\p{Emoji_Component})+$/u;
            if (!emojiRegex.test(emoji)) {
                return await interaction.editReply({
                    content: '❌ Geçersiz emoji!'
                });
            }

            // Gereksinimleri parse et
            const requirements = {};

            if (requiredRoles) {
                const roleIds = requiredRoles.split(',').map(id => id.trim()).filter(id => id);
                if (roleIds.length > 0) {
                    // Rollerin var olduğunu kontrol et
                    for (const roleId of roleIds) {
                        if (!interaction.guild.roles.cache.has(roleId)) {
                            return await interaction.editReply({
                                content: `❌ Rol bulunamadı: ${roleId}`
                            });
                        }
                    }
                    requirements.roles = roleIds;
                }
            }

            if (blacklistedRoles) {
                const roleIds = blacklistedRoles.split(',').map(id => id.trim()).filter(id => id);
                if (roleIds.length > 0) {
                    for (const roleId of roleIds) {
                        if (!interaction.guild.roles.cache.has(roleId)) {
                            return await interaction.editReply({
                                content: `❌ Yasaklı rol bulunamadı: ${roleId}`
                            });
                        }
                    }
                    requirements.blacklistedRoles = roleIds;
                }
            }

            if (minAccountAge) {
                const accountAge = ms(minAccountAge);
                if (!accountAge) {
                    return await interaction.editReply({
                        content: '❌ Geçersiz minimum hesap yaşı! (Örnek: 7d, 1M)'
                    });
                }
                requirements.minAccountAge = minAccountAge;
            }

            if (minJoinAge) {
                const joinAge = ms(minJoinAge);
                if (!joinAge) {
                    return await interaction.editReply({
                        content: '❌ Geçersiz minimum katılım süresi! (Örnek: 1d, 1w)'
                    });
                }
                requirements.minJoinAge = minJoinAge;
            }

            // Çekiliş oluştur
            const result = await bot.giveawayManager.createGiveaway({
                channel,
                host: interaction.user,
                title,
                description,
                prize,
                duration: durationStr, // String olarak gönder, GiveawayManager'da parse edilecek
                winnersCount,
                requirements: Object.keys(requirements).length > 0 ? requirements : null,
                emoji
            });

            if (result.success) {
                const endTime = Math.floor((Date.now() + duration) / 1000);
                
                await interaction.editReply({
                    content: `✅ **Çekiliş başarıyla oluşturuldu!**\n\n` +
                            `**Kanal:** ${channel}\n` +
                            `**Ödül:** ${prize}\n` +
                            `**Süre:** ${durationStr}\n` +
                            `**Kazanan Sayısı:** ${winnersCount}\n` +
                            `**Bitiş Tarihi:** <t:${endTime}:F> (<t:${endTime}:R>)`
                });
            } else {
                await interaction.editReply({
                    content: `❌ **Çekiliş oluşturulamadı!**\n\nHata: ${result.error}`
                });
            }

        } catch (error) {
            bot.logger.error('Çekiliş oluşturulurken hata:', error);
            await interaction.editReply({
                content: '❌ Çekiliş oluşturulurken bir hata oluştu!'
            });
        }
    },

    async handleEnd(interaction, bot) {
        await interaction.deferReply({ ephemeral: true });

        try {
            const messageId = interaction.options.getString('message_id');
            
            const result = await bot.giveawayManager.endGiveaway(messageId, false);
            
            if (result.success) {
                await interaction.editReply({
                    content: `✅ **Çekiliş başarıyla sonlandırıldı!**\n\n` +
                            `${result.winners.length > 0 
                                ? `**Kazanan${result.winners.length > 1 ? 'lar' : ''}:** ${result.winners.map(w => `<@${w}>`).join(', ')}`
                                : '**Hiç katılımcı yok!**'}`
                });
            } else {
                await interaction.editReply({
                    content: `❌ **Çekiliş sonlandırılamadı!**\n\nHata: ${result.error}`
                });
            }
            
        } catch (error) {
            bot.logger.error('Çekiliş sonlandırılırken hata:', error);
            await interaction.editReply({
                content: '❌ Çekiliş sonlandırılırken bir hata oluştu!'
            });
        }
    },

    async handleCancel(interaction, bot) {
        await interaction.deferReply({ ephemeral: true });

        try {
            const messageId = interaction.options.getString('message_id');
            
            const result = await bot.giveawayManager.cancelGiveaway(messageId);
            
            if (result.success) {
                await interaction.editReply({
                    content: '✅ **Çekiliş başarıyla iptal edildi!**'
                });
            } else {
                await interaction.editReply({
                    content: `❌ **Çekiliş iptal edilemedi!**\n\nHata: ${result.error}`
                });
            }
            
        } catch (error) {
            bot.logger.error('Çekiliş iptal edilirken hata:', error);
            await interaction.editReply({
                content: '❌ Çekiliş iptal edilirken bir hata oluştu!'
            });
        }
    },

    async handleList(interaction, bot) {
        await interaction.deferReply({ ephemeral: true });

        try {
            const status = interaction.options.getString('status');
            const giveaways = bot.database.getGuildGiveaways(interaction.guild.id, status);

            if (giveaways.length === 0) {
                return await interaction.editReply({
                    content: `📋 Bu sunucuda ${status ? `**${status}** durumunda ` : ''}çekiliş bulunamadı.`
                });
            }

            const embed = new EmbedBuilder()
                .setTitle(`📋 Sunucu Çekilişleri ${status ? `(${status})` : ''}`)
                .setColor(parseInt(process.env.EMBED_COLOR_INFO, 16) || 0x3498DB)
                .setFooter({ text: `Toplam ${giveaways.length} çekiliş` })
                .setTimestamp();

            let description = '';
            for (let i = 0; i < Math.min(giveaways.length, 10); i++) {
                const giveaway = giveaways[i];
                const statusEmoji = {
                    'active': '🟢',
                    'ended': '🔴',
                    'cancelled': '⚫'
                }[giveaway.status] || '❓';

                description += `${statusEmoji} **${giveaway.prize}**\n`;
                description += `├ ID: \`${giveaway.message_id}\`\n`;
                description += `├ Katılımcı: ${giveaway.entries_count}\n`;
                description += `└ <t:${giveaway.end_time}:R>\n\n`;
            }

            if (giveaways.length > 10) {
                description += `*... ve ${giveaways.length - 10} çekiliş daha*`;
            }

            embed.setDescription(description);

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            bot.logger.error('Çekiliş listesi alınırken hata:', error);
            await interaction.editReply({
                content: '❌ Çekiliş listesi alınırken bir hata oluştu!'
            });
        }
    },

    async handleReroll(interaction, bot) {
        await interaction.deferReply({ ephemeral: true });

        try {
            const messageId = interaction.options.getString('message_id');
            const newWinnerCount = interaction.options.getInteger('winners');

            const giveaway = bot.database.getGiveaway(messageId);
            
            if (!giveaway) {
                return await interaction.editReply({
                    content: '❌ Çekiliş bulunamadı!'
                });
            }

            if (giveaway.status !== 'ended') {
                return await interaction.editReply({
                    content: '❌ Sadece bitmiş çekilişler yeniden çekilebilir!'
                });
            }

            const participants = bot.database.getParticipants(giveaway.id);
            
            if (participants.length === 0) {
                return await interaction.editReply({
                    content: '❌ Bu çekilişte hiç katılımcı yok!'
                });
            }

            const winnersCount = newWinnerCount || giveaway.winners_count;
            const winners = bot.giveawayManager.selectWinners(participants, winnersCount);

            // Eski kazananları sil ve yenilerini ekle
            bot.database.db.prepare('DELETE FROM winners WHERE giveaway_id = ?').run(giveaway.id);
            bot.database.saveWinners(giveaway.id, winners);

            // Güncelle
            if (newWinnerCount) {
                bot.database.db.prepare('UPDATE giveaways SET winners_count = ? WHERE id = ?').run(newWinnerCount, giveaway.id);
            }

            // Mesajı güncelle
            try {
                const channel = await interaction.client.channels.fetch(giveaway.channel_id);
                const message = await channel.messages.fetch(giveaway.message_id);
                const host = await interaction.client.users.fetch(giveaway.host_id);

                const embed = bot.giveawayManager.createGiveawayEmbed({
                    title: giveaway.title,
                    description: giveaway.description,
                    prize: giveaway.prize,
                    host: host,
                    endTime: giveaway.end_time,
                    winnersCount: winnersCount,
                    participantCount: 0,
                    requirements: giveaway.requirements ? JSON.parse(giveaway.requirements) : null,
                    isEnded: true,
                    winners: winners
                });

                const row = bot.giveawayManager.createGiveawayButtons(false);

                await message.edit({
                    embeds: [embed],
                    components: [row]
                });

                // Yeni kazanan duyurusu
                const winnerMentions = winners.map(w => `<@${w}>`).join(', ');
                await channel.send({
                    content: `🔄 **Çekiliş yeniden çekildi!** 🎉\n\n**Yeni kazanan${winners.length > 1 ? 'lar' : ''}:** ${winnerMentions}\n**Ödül:** ${giveaway.prize}\n\nTebrikler!`
                });

            } catch (error) {
                bot.logger.error('Reroll mesajı güncellenirken hata:', error);
            }

            await interaction.editReply({
                content: `✅ **Çekiliş başarıyla yeniden çekildi!**\n\n**Yeni kazanan${winners.length > 1 ? 'lar' : ''}:** ${winners.map(w => `<@${w}>`).join(', ')}`
            });

            bot.logger.logGiveaway('yeniden çekildi', giveaway.id, {
                winners: winners,
                reroller: interaction.user.tag
            });

        } catch (error) {
            bot.logger.error('Çekiliş yeniden çekilirken hata:', error);
            await interaction.editReply({
                content: '❌ Çekiliş yeniden çekilirken bir hata oluştu!'
            });
        }
    }
};