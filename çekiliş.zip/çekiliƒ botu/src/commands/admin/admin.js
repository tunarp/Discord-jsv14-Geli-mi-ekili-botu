const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, AttachmentBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('admin')
        .setDescription('Admin komutları (Sadece bot sahibi)')
        .addSubcommand(subcommand =>
            subcommand
                .setName('settings')
                .setDescription('Bot ayarlarını görüntüle')
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('database')
                .setDescription('Veritabanı yönetimi')
                .addStringOption(option =>
                    option.setName('action')
                        .setDescription('Yapılacak işlem')
                        .setRequired(true)
                        .addChoices(
                            { name: 'İstatistikler', value: 'stats' },
                            { name: 'Temizlik', value: 'cleanup' },
                            { name: 'Yedekle', value: 'backup' },
                            { name: 'Optimize Et', value: 'optimize' }
                        )
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('logs')
                .setDescription('Log dosyalarını yönet')
                .addStringOption(option =>
                    option.setName('action')
                        .setDescription('Yapılacak işlem')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Son Logları Göster', value: 'recent' },
                            { name: 'Log Dosyası Gönder', value: 'file' },
                            { name: 'Log Temizle', value: 'clear' }
                        )
                )
                .addStringOption(option =>
                    option.setName('lines')
                        .setDescription('Gösterilecek satır sayısı (varsayılan: 50)')
                        .setRequired(false)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('system')
                .setDescription('Sistem yönetimi')
                .addStringOption(option =>
                    option.setName('action')
                        .setDescription('Yapılacak işlem')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Yeniden Başlat', value: 'restart' },
                            { name: 'Kapat', value: 'shutdown' },
                            { name: 'Komutları Yenile', value: 'reload' },
                            { name: 'Cache Temizle', value: 'clearcache' }
                        )
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('giveaway')
                .setDescription('Çekiliş yönetimi')
                .addStringOption(option =>
                    option.setName('action')
                        .setDescription('Yapılacak işlem')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Tüm Aktif Çekilişleri Listele', value: 'listall' },
                            { name: 'Çekiliş Sil', value: 'delete' },
                            { name: 'Çekiliş Tamir Et', value: 'repair' }
                        )
                )
                .addStringOption(option =>
                    option.setName('message_id')
                        .setDescription('İşlem yapılacak çekiliş mesaj ID\'si')
                        .setRequired(false)
                )
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    cooldown: 3,
    async execute(interaction, bot) {
        // Bot sahibi kontrolü
        if (interaction.user.id !== process.env.OWNER_ID) {
            return await interaction.reply({
                content: '❌ Bu komut sadece bot sahibi tarafından kullanılabilir!',
                ephemeral: true
            });
        }

        const subcommand = interaction.options.getSubcommand();

        switch (subcommand) {
            case 'settings':
                await this.handleSettings(interaction, bot);
                break;
            case 'database':
                await this.handleDatabase(interaction, bot);
                break;
            case 'logs':
                await this.handleLogs(interaction, bot);
                break;
            case 'system':
                await this.handleSystem(interaction, bot);
                break;
            case 'giveaway':
                await this.handleGiveaway(interaction, bot);
                break;
            default:
                await interaction.reply({
                    content: '❌ Bilinmeyen alt komut!',
                    ephemeral: true
                });
        }
    },

    async handleSettings(interaction, bot) {
        await interaction.deferReply({ ephemeral: true });

        const embed = new EmbedBuilder()
            .setTitle('⚙️ Bot Ayarları')
            .setColor(parseInt(process.env.EMBED_COLOR_INFO, 16) || 0x3498DB)
            .addFields(
                {
                    name: '🔧 Temel Ayarlar',
                    value: 
                        `**Bot ID:** ${process.env.BOT_ID}\n` +
                        `**Owner ID:** ${process.env.OWNER_ID}\n` +
                        `**Guild ID:** ${process.env.GUILD_ID}\n` +
                        `**Log Level:** ${process.env.LOG_LEVEL || 'INFO'}\n` +
                        `**Database Path:** ${process.env.DATABASE_PATH}`,
                    inline: false
                },
                {
                    name: '🎨 Görünüm Ayarları',
                    value: 
                        `**Çekiliş Emojisi:** ${process.env.GIVEAWAY_EMOJI || '🎉'}\n` +
                        `**Başarı Emojisi:** ${process.env.SUCCESS_EMOJI || '✅'}\n` +
                        `**Hata Emojisi:** ${process.env.ERROR_EMOJI || '❌'}\n` +
                        `**Yükleniyor Emojisi:** ${process.env.LOADING_EMOJI || '⏳'}`,
                    inline: false
                },
                {
                    name: '🎨 Renk Ayarları',
                    value: 
                        `**Başarı:** #${(parseInt(process.env.EMBED_COLOR_SUCCESS, 16) || 0x00FF00).toString(16).toUpperCase()}\n` +
                        `**Hata:** #${(parseInt(process.env.EMBED_COLOR_ERROR, 16) || 0xFF0000).toString(16).toUpperCase()}\n` +
                        `**Bilgi:** #${(parseInt(process.env.EMBED_COLOR_INFO, 16) || 0x3498DB).toString(16).toUpperCase()}\n` +
                        `**Uyarı:** #${(parseInt(process.env.EMBED_COLOR_WARNING, 16) || 0xF39C12).toString(16).toUpperCase()}`,
                    inline: false
                }
            )
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    },

    async handleDatabase(interaction, bot) {
        await interaction.deferReply({ ephemeral: true });

        const action = interaction.options.getString('action');

        try {
            switch (action) {
                case 'stats':
                    const stats = {
                        totalGiveaways: bot.database.db.prepare('SELECT COUNT(*) as count FROM giveaways').get().count,
                        activeGiveaways: bot.database.db.prepare('SELECT COUNT(*) as count FROM giveaways WHERE status = ?').get('active').count,
                        endedGiveaways: bot.database.db.prepare('SELECT COUNT(*) as count FROM giveaways WHERE status = ?').get('ended').count,
                        totalParticipants: bot.database.db.prepare('SELECT COUNT(*) as count FROM participants').get().count,
                        totalWinners: bot.database.db.prepare('SELECT COUNT(*) as count FROM winners').get().count
                    };

                    const dbSize = fs.statSync(bot.database.dbPath).size;

                    const embed = new EmbedBuilder()
                        .setTitle('📊 Veritabanı İstatistikleri')
                        .setColor(parseInt(process.env.EMBED_COLOR_INFO, 16) || 0x3498DB)
                        .addFields(
                            {
                                name: '📈 Kayıt Sayıları',
                                value: 
                                    `**Toplam Çekiliş:** ${stats.totalGiveaways.toLocaleString()}\n` +
                                    `**Aktif Çekiliş:** ${stats.activeGiveaways.toLocaleString()}\n` +
                                    `**Bitmiş Çekiliş:** ${stats.endedGiveaways.toLocaleString()}\n` +
                                    `**Toplam Katılım:** ${stats.totalParticipants.toLocaleString()}\n` +
                                    `**Toplam Kazanan:** ${stats.totalWinners.toLocaleString()}`,
                                inline: false
                            },
                            {
                                name: '💾 Dosya Bilgileri',
                                value: 
                                    `**Dosya Boyutu:** ${(dbSize / 1024 / 1024).toFixed(2)} MB\n` +
                                    `**Dosya Yolu:** ${bot.database.dbPath}`,
                                inline: false
                            }
                        )
                        .setTimestamp();

                    await interaction.editReply({ embeds: [embed] });
                    break;

                case 'cleanup':
                    const cleanupResult = bot.database.cleanup();
                    await interaction.editReply({
                        content: `✅ Veritabanı temizliği tamamlandı! ${cleanupResult.changes} eski kayıt silindi.`
                    });
                    break;

                case 'backup':
                    const backupDir = path.join(process.cwd(), 'backups');
                    if (!fs.existsSync(backupDir)) {
                        fs.mkdirSync(backupDir, { recursive: true });
                    }

                    const backupPath = path.join(backupDir, `backup-${new Date().toISOString().split('T')[0]}.db`);
                    fs.copyFileSync(bot.database.dbPath, backupPath);

                    await interaction.editReply({
                        content: `✅ Veritabanı yedeklendi: \`${backupPath}\``
                    });
                    break;

                case 'optimize':
                    bot.database.db.pragma('optimize');
                    await interaction.editReply({
                        content: '✅ Veritabanı optimize edildi!'
                    });
                    break;
            }
        } catch (error) {
            bot.logger.error('Database admin komutu hatası:', error);
            await interaction.editReply({
                content: `❌ Veritabanı işlemi sırasında hata: ${error.message}`
            });
        }
    },

    async handleLogs(interaction, bot) {
        await interaction.deferReply({ ephemeral: true });

        const action = interaction.options.getString('action');
        const lines = parseInt(interaction.options.getString('lines')) || 50;

        try {
            const logFile = bot.logger.logFile;

            switch (action) {
                case 'recent':
                    if (!fs.existsSync(logFile)) {
                        return await interaction.editReply({
                            content: '❌ Log dosyası bulunamadı!'
                        });
                    }

                    const logContent = fs.readFileSync(logFile, 'utf8');
                    const logLines = logContent.split('\n').slice(-lines).join('\n');

                    if (logLines.length > 4000) {
                        const attachment = new AttachmentBuilder(Buffer.from(logLines), { name: 'recent-logs.txt' });
                        await interaction.editReply({
                            content: `📝 Son ${lines} satır log dosyası (çok uzun olduğu için dosya olarak gönderildi):`,
                            files: [attachment]
                        });
                    } else {
                        await interaction.editReply({
                            content: `📝 **Son ${lines} satır log:**\n\`\`\`\n${logLines}\n\`\`\``
                        });
                    }
                    break;

                case 'file':
                    if (!fs.existsSync(logFile)) {
                        return await interaction.editReply({
                            content: '❌ Log dosyası bulunamadı!'
                        });
                    }

                    const attachment = new AttachmentBuilder(logFile, { 
                        name: `bot-logs-${new Date().toISOString().split('T')[0]}.log` 
                    });

                    await interaction.editReply({
                        content: '📄 Güncel log dosyası:',
                        files: [attachment]
                    });
                    break;

                case 'clear':
                    if (fs.existsSync(logFile)) {
                        fs.writeFileSync(logFile, '');
                        await interaction.editReply({
                            content: '✅ Log dosyası temizlendi!'
                        });
                    } else {
                        await interaction.editReply({
                            content: '❌ Log dosyası bulunamadı!'
                        });
                    }
                    break;
            }
        } catch (error) {
            bot.logger.error('Log admin komutu hatası:', error);
            await interaction.editReply({
                content: `❌ Log işlemi sırasında hata: ${error.message}`
            });
        }
    },

    async handleSystem(interaction, bot) {
        await interaction.deferReply({ ephemeral: true });

        const action = interaction.options.getString('action');

        try {
            switch (action) {
                case 'restart':
                    await interaction.editReply({
                        content: '🔄 Bot yeniden başlatılıyor... (Bu işlem birkaç dakika sürebilir)'
                    });
                    bot.logger.info('Bot yeniden başlatılıyor (admin komutuyla)');
                    process.exit(0);
                    break;

                case 'shutdown':
                    await interaction.editReply({
                        content: '⛔ Bot kapatılıyor...'
                    });
                    bot.logger.info('Bot kapatılıyor (admin komutuyla)');
                    bot.giveawayManager.stop();
                    bot.database.close();
                    process.exit(0);
                    break;

                case 'reload':
                    await bot.deployCommands();
                    await interaction.editReply({
                        content: '🔄 Slash komutları yeniden yüklendi!'
                    });
                    break;

                case 'clearcache':
                    // Command cache temizle
                    interaction.client.commands.clear();
                    
                    // Cooldown cache temizle
                    interaction.client.cooldowns.clear();

                    // Guild cache kısmi temizliği
                    interaction.client.guilds.cache.forEach(guild => {
                        guild.members.cache.clear();
                        guild.channels.cache.clear();
                        guild.roles.cache.clear();
                    });

                    await interaction.editReply({
                        content: '🧹 Cache temizlendi!'
                    });
                    break;
            }
        } catch (error) {
            bot.logger.error('System admin komutu hatası:', error);
            await interaction.editReply({
                content: `❌ Sistem işlemi sırasında hata: ${error.message}`
            });
        }
    },

    async handleGiveaway(interaction, bot) {
        await interaction.deferReply({ ephemeral: true });

        const action = interaction.options.getString('action');
        const messageId = interaction.options.getString('message_id');

        try {
            switch (action) {
                case 'listall':
                    const allActiveGiveaways = bot.database.getActiveGiveaways();
                    
                    if (allActiveGiveaways.length === 0) {
                        return await interaction.editReply({
                            content: '📋 Hiç aktif çekiliş bulunamadı.'
                        });
                    }

                    let listText = '🎉 **Tüm Aktif Çekilişler:**\n\n';
                    for (const giveaway of allActiveGiveaways.slice(0, 20)) {
                        const guild = interaction.client.guilds.cache.get(giveaway.guild_id);
                        const guildName = guild ? guild.name : 'Bilinmeyen Sunucu';
                        
                        listText += `**${giveaway.prize}**\n`;
                        listText += `├ Sunucu: ${guildName}\n`;
                        listText += `├ ID: \`${giveaway.message_id}\`\n`;
                        listText += `├ Katılımcı: ${giveaway.entries_count}\n`;
                        listText += `└ Bitiş: <t:${giveaway.end_time}:R>\n\n`;
                    }

                    if (allActiveGiveaways.length > 20) {
                        listText += `*... ve ${allActiveGiveaways.length - 20} çekiliş daha*`;
                    }

                    await interaction.editReply({ content: listText });
                    break;

                case 'delete':
                    if (!messageId) {
                        return await interaction.editReply({
                            content: '❌ Mesaj ID\'si gereklidir!'
                        });
                    }

                    const giveaway = bot.database.getGiveaway(messageId);
                    if (!giveaway) {
                        return await interaction.editReply({
                            content: '❌ Çekiliş bulunamadı!'
                        });
                    }

                    bot.database.deleteGiveaway(giveaway.id);
                    await interaction.editReply({
                        content: `✅ Çekiliş silindi: **${giveaway.prize}**`
                    });
                    break;

                case 'repair':
                    if (!messageId) {
                        return await interaction.editReply({
                            content: '❌ Mesaj ID\'si gereklidir!'
                        });
                    }

                    const repairGiveaway = bot.database.getGiveaway(messageId);
                    if (!repairGiveaway) {
                        return await interaction.editReply({
                            content: '❌ Çekiliş bulunamadı!'
                        });
                    }

                    try {
                        const channel = await interaction.client.channels.fetch(repairGiveaway.channel_id);
                        const message = await channel.messages.fetch(repairGiveaway.message_id);
                        
                        await bot.giveawayManager.updateGiveawayMessage(message, repairGiveaway.id);
                        
                        await interaction.editReply({
                            content: `✅ Çekiliş tamir edildi: **${repairGiveaway.prize}**`
                        });
                    } catch (error) {
                        await interaction.editReply({
                            content: `❌ Çekiliş tamir edilemedi: ${error.message}`
                        });
                    }
                    break;
            }
        } catch (error) {
            bot.logger.error('Giveaway admin komutu hatası:', error);
            await interaction.editReply({
                content: `❌ Çekiliş yönetimi sırasında hata: ${error.message}`
            });
        }
    }
};