const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

class DatabaseManager {
    constructor() {
        this.dbPath = process.env.DATABASE_PATH || './database/giveaways.db';
        this.db = null;
        
        // Database klasörünü oluştur
        const dbDir = path.dirname(this.dbPath);
        if (!fs.existsSync(dbDir)) {
            fs.mkdirSync(dbDir, { recursive: true });
        }
    }

    async init() {
        try {
            this.db = new Database(this.dbPath);
            
            // WAL mode için performans optimizasyonu
            this.db.pragma('journal_mode = WAL');
            this.db.pragma('synchronous = NORMAL');
            this.db.pragma('cache_size = 1000000');
            this.db.pragma('foreign_keys = ON');
            this.db.pragma('temp_store = MEMORY');

            this.createTables();
            console.log('✅ Veritabanı başarıyla başlatıldı');
        } catch (error) {
            console.error('❌ Veritabanı başlatılamadı:', error);
            throw error;
        }
    }

    createTables() {
        // Çekiliş tablosu
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS giveaways (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message_id TEXT UNIQUE NOT NULL,
                channel_id TEXT NOT NULL,
                guild_id TEXT NOT NULL,
                host_id TEXT NOT NULL,
                title TEXT NOT NULL,
                description TEXT,
                prize TEXT NOT NULL,
                winners_count INTEGER DEFAULT 1,
                entries_count INTEGER DEFAULT 0,
                start_time INTEGER NOT NULL,
                end_time INTEGER NOT NULL,
                status TEXT DEFAULT 'active',
                requirements TEXT,
                emoji TEXT DEFAULT '🎉',
                created_at INTEGER DEFAULT (strftime('%s', 'now')),
                updated_at INTEGER DEFAULT (strftime('%s', 'now'))
            )
        `);

        // Katılımcılar tablosu
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS participants (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                giveaway_id INTEGER NOT NULL,
                user_id TEXT NOT NULL,
                joined_at INTEGER DEFAULT (strftime('%s', 'now')),
                FOREIGN KEY (giveaway_id) REFERENCES giveaways (id) ON DELETE CASCADE,
                UNIQUE(giveaway_id, user_id)
            )
        `);

        // Kazananlar tablosu
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS winners (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                giveaway_id INTEGER NOT NULL,
                user_id TEXT NOT NULL,
                position INTEGER NOT NULL,
                claimed BOOLEAN DEFAULT FALSE,
                claimed_at INTEGER,
                FOREIGN KEY (giveaway_id) REFERENCES giveaways (id) ON DELETE CASCADE
            )
        `);

        // İndeksler
        this.db.exec(`
            CREATE INDEX IF NOT EXISTS idx_giveaways_message_id ON giveaways (message_id);
            CREATE INDEX IF NOT EXISTS idx_giveaways_guild_id ON giveaways (guild_id);
            CREATE INDEX IF NOT EXISTS idx_giveaways_status ON giveaways (status);
            CREATE INDEX IF NOT EXISTS idx_giveaways_end_time ON giveaways (end_time);
            CREATE INDEX IF NOT EXISTS idx_participants_giveaway_id ON participants (giveaway_id);
            CREATE INDEX IF NOT EXISTS idx_participants_user_id ON participants (user_id);
            CREATE INDEX IF NOT EXISTS idx_winners_giveaway_id ON winners (giveaway_id);
        `);
    }

    // Çekiliş oluştur
    createGiveaway(data) {
        const stmt = this.db.prepare(`
            INSERT INTO giveaways (
                message_id, channel_id, guild_id, host_id, title, description, 
                prize, winners_count, start_time, end_time, requirements, emoji
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        return stmt.run(
            data.messageId,
            data.channelId,
            data.guildId,
            data.hostId,
            data.title,
            data.description || null,
            data.prize,
            data.winnersCount || 1,
            data.startTime,
            data.endTime,
            data.requirements ? JSON.stringify(data.requirements) : null,
            data.emoji || '🎉'
        );
    }

    // Çekiliş getir
    getGiveaway(messageId) {
        const stmt = this.db.prepare('SELECT * FROM giveaways WHERE message_id = ?');
        const giveaway = stmt.get(messageId);
        
        if (giveaway && giveaway.requirements) {
            giveaway.requirements = JSON.parse(giveaway.requirements);
        }
        
        return giveaway;
    }

    // Aktif çekilişleri getir
    getActiveGiveaways() {
        const stmt = this.db.prepare(`
            SELECT * FROM giveaways 
            WHERE status = 'active' AND end_time > strftime('%s', 'now')
        `);
        const giveaways = stmt.all();
        
        return giveaways.map(giveaway => {
            if (giveaway.requirements) {
                giveaway.requirements = JSON.parse(giveaway.requirements);
            }
            return giveaway;
        });
    }

    // Bitmiş çekilişleri getir
    getExpiredGiveaways() {
        const stmt = this.db.prepare(`
            SELECT * FROM giveaways 
            WHERE status = 'active' AND end_time <= strftime('%s', 'now')
        `);
        const giveaways = stmt.all();
        
        return giveaways.map(giveaway => {
            if (giveaway.requirements) {
                giveaway.requirements = JSON.parse(giveaway.requirements);
            }
            return giveaway;
        });
    }

    // Sunucu çekilişlerini getir
    getGuildGiveaways(guildId, status = null) {
        let query = 'SELECT * FROM giveaways WHERE guild_id = ?';
        let params = [guildId];
        
        if (status) {
            query += ' AND status = ?';
            params.push(status);
        }
        
        query += ' ORDER BY created_at DESC';
        
        const stmt = this.db.prepare(query);
        const giveaways = stmt.all(...params);
        
        return giveaways.map(giveaway => {
            if (giveaway.requirements) {
                giveaway.requirements = JSON.parse(giveaway.requirements);
            }
            return giveaway;
        });
    }

    // Katılımcı ekle
    addParticipant(giveawayId, userId) {
        const stmt = this.db.prepare(`
            INSERT OR IGNORE INTO participants (giveaway_id, user_id) 
            VALUES (?, ?)
        `);
        const result = stmt.run(giveawayId, userId);
        
        if (result.changes > 0) {
            // Entry count'u güncelle
            const updateStmt = this.db.prepare(`
                UPDATE giveaways 
                SET entries_count = entries_count + 1, updated_at = strftime('%s', 'now') 
                WHERE id = ?
            `);
            updateStmt.run(giveawayId);
        }
        
        return result.changes > 0;
    }

    // Katılımcı çıkar
    removeParticipant(giveawayId, userId) {
        const stmt = this.db.prepare(`
            DELETE FROM participants 
            WHERE giveaway_id = ? AND user_id = ?
        `);
        const result = stmt.run(giveawayId, userId);
        
        if (result.changes > 0) {
            // Entry count'u güncelle
            const updateStmt = this.db.prepare(`
                UPDATE giveaways 
                SET entries_count = entries_count - 1, updated_at = strftime('%s', 'now') 
                WHERE id = ?
            `);
            updateStmt.run(giveawayId);
        }
        
        return result.changes > 0;
    }

    // Katılımcıları getir
    getParticipants(giveawayId) {
        const stmt = this.db.prepare(`
            SELECT user_id, joined_at FROM participants 
            WHERE giveaway_id = ? 
            ORDER BY joined_at ASC
        `);
        return stmt.all(giveawayId);
    }

    // Kullanıcının katılıp katılmadığını kontrol et
    isParticipant(giveawayId, userId) {
        const stmt = this.db.prepare(`
            SELECT 1 FROM participants 
            WHERE giveaway_id = ? AND user_id = ?
        `);
        return stmt.get(giveawayId, userId) !== undefined;
    }

    // Çekiliş durumunu güncelle
    updateGiveawayStatus(giveawayId, status) {
        const stmt = this.db.prepare(`
            UPDATE giveaways 
            SET status = ?, updated_at = strftime('%s', 'now') 
            WHERE id = ?
        `);
        return stmt.run(status, giveawayId);
    }

    // Kazananları kaydet
    saveWinners(giveawayId, winners) {
        const stmt = this.db.prepare(`
            INSERT INTO winners (giveaway_id, user_id, position) 
            VALUES (?, ?, ?)
        `);
        
        const transaction = this.db.transaction(() => {
            winners.forEach((userId, index) => {
                stmt.run(giveawayId, userId, index + 1);
            });
        });
        
        return transaction();
    }

    // Kazananları getir
    getWinners(giveawayId) {
        const stmt = this.db.prepare(`
            SELECT * FROM winners 
            WHERE giveaway_id = ? 
            ORDER BY position ASC
        `);
        return stmt.all(giveawayId);
    }

    // Çekiliş sil
    deleteGiveaway(giveawayId) {
        const stmt = this.db.prepare('DELETE FROM giveaways WHERE id = ?');
        return stmt.run(giveawayId);
    }

    // Veritabanını kapat
    close() {
        if (this.db) {
            this.db.close();
        }
    }

    // Temizlik işlemleri
    cleanup() {
        // Eski logları temizle (30 günden eski)
        const stmt = this.db.prepare(`
            DELETE FROM giveaways 
            WHERE status = 'ended' AND updated_at < strftime('%s', 'now', '-30 days')
        `);
        return stmt.run();
    }
}

module.exports = { Database: DatabaseManager };