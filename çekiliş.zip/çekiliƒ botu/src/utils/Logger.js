const chalk = require('chalk');
const fs = require('fs');
const path = require('path');

class Logger {
    constructor() {
        this.logLevel = process.env.LOG_LEVEL || 'INFO';
        this.logLevels = {
            DEBUG: 0,
            INFO: 1,
            WARN: 2,
            ERROR: 3
        };
        
        // Logs klasörünü oluştur
        this.logsDir = path.join(process.cwd(), 'logs');
        if (!fs.existsSync(this.logsDir)) {
            fs.mkdirSync(this.logsDir, { recursive: true });
        }
        
        this.logFile = path.join(this.logsDir, `bot-${new Date().toISOString().split('T')[0]}.log`);
    }

    shouldLog(level) {
        return this.logLevels[level] >= this.logLevels[this.logLevel];
    }

    formatMessage(level, message, ...args) {
        const timestamp = new Date().toISOString();
        const formattedArgs = args.length > 0 ? ' ' + args.map(arg => 
            typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
        ).join(' ') : '';
        
        return `[${timestamp}] [${level}] ${message}${formattedArgs}`;
    }

    writeToFile(message) {
        try {
            fs.appendFileSync(this.logFile, message + '\n');
        } catch (error) {
            console.error('Log dosyasına yazılamadı:', error);
        }
    }

    debug(message, ...args) {
        if (!this.shouldLog('DEBUG')) return;
        
        const formatted = this.formatMessage('DEBUG', message, ...args);
        console.log(chalk.gray(formatted));
        this.writeToFile(formatted);
    }

    info(message, ...args) {
        if (!this.shouldLog('INFO')) return;
        
        const formatted = this.formatMessage('INFO', message, ...args);
        console.log(chalk.blue(formatted));
        this.writeToFile(formatted);
    }

    success(message, ...args) {
        if (!this.shouldLog('INFO')) return;
        
        const formatted = this.formatMessage('SUCCESS', message, ...args);
        console.log(chalk.green(formatted));
        this.writeToFile(formatted);
    }

    warn(message, ...args) {
        if (!this.shouldLog('WARN')) return;
        
        const formatted = this.formatMessage('WARN', message, ...args);
        console.log(chalk.yellow(formatted));
        this.writeToFile(formatted);
    }

    error(message, ...args) {
        if (!this.shouldLog('ERROR')) return;
        
        const formatted = this.formatMessage('ERROR', message, ...args);
        console.log(chalk.red(formatted));
        this.writeToFile(formatted);
    }

    logCommand(guildName, userName, commandName, args = []) {
        const message = `Komut kullanıldı: ${commandName} | Sunucu: ${guildName} | Kullanıcı: ${userName}${args.length ? ' | Parametreler: ' + args.join(', ') : ''}`;
        this.info(message);
    }

    logGiveaway(action, giveawayId, details = {}) {
        const message = `Çekiliş ${action}: ID=${giveawayId}`;
        const detailsStr = Object.keys(details).length > 0 ? ' | Detaylar: ' + JSON.stringify(details) : '';
        this.info(message + detailsStr);
    }
}

module.exports = { Logger };