const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const ms = require('ms');

class GiveawayManager {
    constructor(bot) {
        this.bot = bot;
        this.client = bot.client;
        this.database = bot.database;
        this.logger = bot.logger;
        
        // Otomatik kontrol intervali (her 30 saniye)
        this.checkInterval = null;
        this.startAutoCheck();
    }

    startAutoCheck() {
        // Botun hazır olmasını bekle
        this.client.once('ready', () => {
            this.checkInterval = setInterval(() => {
                this.checkExpiredGiveaways();
            }, 30000); // 30 saniye

            this.logger.info('Çekiliş otomatik kontrol sistemi başlatıldı');
        });
    }

    async checkExpiredGiveaways() {
        try {
            const expiredGiveaways = this.database.getExpiredGiveaways();
            
            for (const giveaway of expiredGiveaways) {
                await this.endGiveaway(giveaway.message_id, true);
            }
        } catch (error) {
            this.logger.error('Bitmiş çekilişler kontrol edilirken hata:', error);
        }
    }

    async createGiveaway(options) {
        try {
            const {
                channel,
                host,
                title,
                description,
                prize,
                duration,
                winnersCount = 1,
                requirements,
                emoji = '🎉'
            } = options;

            // Duration'ı kontrol et ve parse et
            const durationMs = ms(duration);
            if (!durationMs || isNaN(durationMs)) {
                throw new Error(`Geçersiz süre formatı: ${duration}`);
            }

            const startTime = Math.floor(Date.now() / 1000);
            const endTime = startTime + Math.floor(durationMs / 1000);

            // endTime'ın geçerli olduğunu kontrol et
            if (!endTime || isNaN(endTime) || endTime <= startTime) {
                throw new Error('Çekiliş bitiş zamanı hesaplanamadı');
            }

            // Embed oluştur
            const embed = this.createGiveawayEmbed({
                title,
                description,
                prize,
                host,
                endTime,
                winnersCount,
                participantCount: 0,
                requirements
            });

            // Butonlar oluştur
            const row = this.createGiveawayButtons(true);

            // Mesajı gönder
            const message = await channel.send({
                embeds: [embed],
                components: [row]
            });

            // Veritabanına kaydet
            const giveawayData = {
                messageId: message.id,
                channelId: channel.id,
                guildId: channel.guild.id,
                hostId: host.id,
                title,
                description,
                prize,
                winnersCount,
                startTime,
                endTime,
                requirements,
                emoji
            };

            const result = this.database.createGiveaway(giveawayData);

            // Reakciyon ekle
            await message.react(emoji);

            this.logger.logGiveaway('oluşturuldu', result.lastInsertRowid, {
                title,
                prize,
                duration,
                winnersCount,
                guild: channel.guild.name
            });

            return {
                success: true,
                giveaway: {
                    id: result.lastInsertRowid,
                    messageId: message.id,
                    endTime
                }
            };

        } catch (error) {
            this.logger.error('Çekiliş oluşturulurken hata:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    createGiveawayEmbed(data) {
        const {
            title,
            description,
            prize,
            host,
            endTime,
            winnersCount,
            participantCount,
            requirements,
            isEnded = false,
            winners = null
        } = data;

        const embed = new EmbedBuilder()
            .setTitle(isEnded ? '🎊 Çekiliş Bitti!' : '🎉 Çekiliş!')
            .setDescription(
                `**Ödül:** ${prize}\n\n` +
                (description ? `${description}\n\n` : '') +
                (isEnded 
                    ? (winners && winners.length > 0 
                        ? `**Kazanan${winnersCount > 1 ? 'lar' : ''}:** ${winners.map(w => `<@${w}>`).join(', ')}`
                        : '**Hiç katılımcı yok!**'
                    )
                    : `**Kazanan sayısı:** ${winnersCount}\n` +
                      `**Bitiş tarihi:** <t:${endTime}:F> (<t:${endTime}:R>)\n` +
                      `**Katılımcı sayısı:** ${participantCount}`
                ) +
                '\n\n' +
                (requirements && Object.keys(requirements).length > 0 
                    ? this.formatRequirements(requirements) + '\n\n'
                    : ''
                ) +
                (isEnded 
                    ? '**Çekiliş sona erdi!**'
                    : '**Katılmak için aşağıdaki butona tıklayın!**'
                )
            )
            .setColor(isEnded ? parseInt(process.env.EMBED_COLOR_SUCCESS, 16) || 0x00FF00 : parseInt(process.env.EMBED_COLOR_INFO, 16) || 0x3498DB)
            .setFooter({
                text: `Düzenleyen: ${host.username}`,
                iconURL: host.displayAvatarURL()
            })
            .setTimestamp();

        if (!isEnded) {
            embed.setThumbnail('https://cdn.discordapp.com/emojis/784212004997087241.png');
        }

        return embed;
    }

    createGiveawayButtons(active = true) {
        const joinButton = new ButtonBuilder()
            .setCustomId('giveaway_join')
            .setLabel('🎉 Çekilişe Katıl')
            .setStyle(ButtonStyle.Success)
            .setDisabled(!active);

        const leaveButton = new ButtonBuilder()
            .setCustomId('giveaway_leave')
            .setLabel('❌ Çekilişten Ayrıl')
            .setStyle(ButtonStyle.Danger)
            .setDisabled(!active);

        const infoButton = new ButtonBuilder()
            .setCustomId('giveaway_info')
            .setLabel('📊 Bilgi')
            .setStyle(ButtonStyle.Secondary);

        return new ActionRowBuilder().addComponents(joinButton, leaveButton, infoButton);
    }

    formatRequirements(requirements) {
        let formatted = '**Gereksinimler:**\n';
        
        if (requirements.roles && requirements.roles.length > 0) {
            formatted += `• Gerekli roller: ${requirements.roles.map(r => `<@&${r}>`).join(', ')}\n`;
        }
        
        if (requirements.minAccountAge) {
            formatted += `• Minimum hesap yaşı: ${requirements.minAccountAge}\n`;
        }
        
        if (requirements.minJoinAge) {
            formatted += `• Sunucuya katılım süresi: ${requirements.minJoinAge}\n`;
        }
        
        if (requirements.blacklistedRoles && requirements.blacklistedRoles.length > 0) {
            formatted += `• Bu rollere sahip olamazsınız: ${requirements.blacklistedRoles.map(r => `<@&${r}>`).join(', ')}\n`;
        }

        return formatted;
    }

    async handleParticipation(interaction, action) {
        try {
            const giveaway = this.database.getGiveaway(interaction.message.id);
            
            if (!giveaway) {
                return await interaction.reply({
                    content: '❌ Bu çekiliş bulunamadı!',
                    ephemeral: true
                });
            }

            if (giveaway.status !== 'active') {
                return await interaction.reply({
                    content: '❌ Bu çekiliş artık aktif değil!',
                    ephemeral: true
                });
            }

            if (giveaway.end_time <= Math.floor(Date.now() / 1000)) {
                return await interaction.reply({
                    content: '❌ Bu çekiliş süresi dolmuş!',
                    ephemeral: true
                });
            }

            const userId = interaction.user.id;
            const member = interaction.member;

            if (action === 'join') {
                return await this.handleJoin(interaction, giveaway, userId, member);
            } else if (action === 'leave') {
                return await this.handleLeave(interaction, giveaway, userId);
            } else if (action === 'info') {
                return await this.handleInfo(interaction, giveaway);
            }

        } catch (error) {
            this.logger.error('Çekiliş katılımı işlenirken hata:', error);
            await interaction.reply({
                content: '❌ Bir hata oluştu! Lütfen daha sonra tekrar deneyin.',
                ephemeral: true
            });
        }
    }

    async handleJoin(interaction, giveaway, userId, member) {
        // Host kendi çekilişine katılamaz
        if (giveaway.host_id === userId) {
            return await interaction.reply({
                content: '❌ Kendi çekilişinize katılamazsınız!',
                ephemeral: true
            });
        }

        // Zaten katıldı mı kontrol et
        if (this.database.isParticipant(giveaway.id, userId)) {
            return await interaction.reply({
                content: '❌ Zaten bu çekilişe katılmışsınız!',
                ephemeral: true
            });
        }

        // Gereksinimleri kontrol et
        if (giveaway.requirements) {
            const requirements = JSON.parse(giveaway.requirements);
            const checkResult = await this.checkRequirements(member, requirements);
            
            if (!checkResult.passed) {
                return await interaction.reply({
                    content: `❌ Gereksinimler karşılanmıyor:\n${checkResult.reason}`,
                    ephemeral: true
                });
            }
        }

        // Katılımcıyı ekle
        const added = this.database.addParticipant(giveaway.id, userId);
        
        if (added) {
            // Embed'i güncelle
            await this.updateGiveawayMessage(interaction.message, giveaway.id);
            
            await interaction.reply({
                content: '✅ Çekilişe başarıyla katıldınız!',
                ephemeral: true
            });

            this.logger.logGiveaway('katılım', giveaway.id, {
                user: interaction.user.tag,
                userId: userId
            });
        } else {
            await interaction.reply({
                content: '❌ Çekilişe katılırken bir hata oluştu!',
                ephemeral: true
            });
        }
    }

    async handleLeave(interaction, giveaway, userId) {
        if (!this.database.isParticipant(giveaway.id, userId)) {
            return await interaction.reply({
                content: '❌ Bu çekilişe katılmamışsınız!',
                ephemeral: true
            });
        }

        const removed = this.database.removeParticipant(giveaway.id, userId);
        
        if (removed) {
            // Embed'i güncelle
            await this.updateGiveawayMessage(interaction.message, giveaway.id);
            
            await interaction.reply({
                content: '✅ Çekilişten başarıyla ayrıldınız!',
                ephemeral: true
            });

            this.logger.logGiveaway('ayrılma', giveaway.id, {
                user: interaction.user.tag,
                userId: userId
            });
        } else {
            await interaction.reply({
                content: '❌ Çekilişten ayrılırken bir hata oluştu!',
                ephemeral: true
            });
        }
    }

    async handleInfo(interaction, giveaway) {
        const participants = this.database.getParticipants(giveaway.id);
        const host = await this.client.users.fetch(giveaway.host_id);
        
        const embed = new EmbedBuilder()
            .setTitle('📊 Çekiliş Bilgileri')
            .setDescription(
                `**Çekiliş:** ${giveaway.title}\n` +
                `**Ödül:** ${giveaway.prize}\n` +
                `**Düzenleyen:** ${host.username}\n` +
                `**Kazanan Sayısı:** ${giveaway.winners_count}\n` +
                `**Katılımcı Sayısı:** ${participants.length}\n` +
                `**Bitiş Tarihi:** <t:${giveaway.end_time}:F> (<t:${giveaway.end_time}:R>)\n` +
                `**Durum:** ${giveaway.status === 'active' ? '🟢 Aktif' : '🔴 Pasif'}`
            )
            .setColor(parseInt(process.env.EMBED_COLOR_INFO, 16) || 0x3498DB)
            .setTimestamp();

        await interaction.reply({
            embeds: [embed],
            ephemeral: true
        });
    }

    async checkRequirements(member, requirements) {
        try {
            // Rol gereksinimleri
            if (requirements.roles && requirements.roles.length > 0) {
                const hasRequiredRole = requirements.roles.some(roleId => 
                    member.roles.cache.has(roleId)
                );
                
                if (!hasRequiredRole) {
                    return {
                        passed: false,
                        reason: 'Gerekli rollerden birine sahip değilsiniz!'
                    };
                }
            }

            // Yasaklı roller
            if (requirements.blacklistedRoles && requirements.blacklistedRoles.length > 0) {
                const hasBlacklistedRole = requirements.blacklistedRoles.some(roleId => 
                    member.roles.cache.has(roleId)
                );
                
                if (hasBlacklistedRole) {
                    return {
                        passed: false,
                        reason: 'Yasaklı rollerden birine sahipsiniz!'
                    };
                }
            }

            // Minimum hesap yaşı
            if (requirements.minAccountAge) {
                const accountAge = Date.now() - member.user.createdTimestamp;
                const requiredAge = ms(requirements.minAccountAge);
                
                if (accountAge < requiredAge) {
                    return {
                        passed: false,
                        reason: `Hesabınız en az ${requirements.minAccountAge} eski olmalı!`
                    };
                }
            }

            // Minimum sunucu katılım süresi
            if (requirements.minJoinAge) {
                const joinAge = Date.now() - member.joinedTimestamp;
                const requiredJoinAge = ms(requirements.minJoinAge);
                
                if (joinAge < requiredJoinAge) {
                    return {
                        passed: false,
                        reason: `Sunucuya en az ${requirements.minJoinAge} önce katılmış olmalısınız!`
                    };
                }
            }

            return { passed: true };
            
        } catch (error) {
            this.logger.error('Gereksinim kontrolü sırasında hata:', error);
            return {
                passed: false,
                reason: 'Gereksinim kontrolü sırasında bir hata oluştu!'
            };
        }
    }

    async updateGiveawayMessage(message, giveawayId) {
        try {
            const giveaway = this.database.getGiveaway(message.id);
            if (!giveaway) return;

            const host = await this.client.users.fetch(giveaway.host_id);
            const participants = this.database.getParticipants(giveaway.id);

            const embed = this.createGiveawayEmbed({
                title: giveaway.title,
                description: giveaway.description,
                prize: giveaway.prize,
                host: host,
                endTime: giveaway.end_time,
                winnersCount: giveaway.winners_count,
                participantCount: participants.length,
                requirements: giveaway.requirements ? JSON.parse(giveaway.requirements) : null
            });

            const row = this.createGiveawayButtons(giveaway.status === 'active');

            await message.edit({
                embeds: [embed],
                components: [row]
            });

        } catch (error) {
            this.logger.error('Çekiliş mesajı güncellenirken hata:', error);
        }
    }

    async endGiveaway(messageId, automatic = false) {
        try {
            const giveaway = this.database.getGiveaway(messageId);
            
            if (!giveaway || giveaway.status !== 'active') {
                return { success: false, error: 'Çekiliş bulunamadı veya zaten sonlanmış!' };
            }

            const participants = this.database.getParticipants(giveaway.id);
            
            if (participants.length === 0) {
                // Katılımcı yok
                await this.finishGiveawayWithoutWinners(giveaway, automatic);
                return { success: true, winners: [] };
            }

            // Kazanan seç
            const winners = this.selectWinners(participants, giveaway.winners_count);
            
            // Kazananları kaydet
            this.database.saveWinners(giveaway.id, winners);
            this.database.updateGiveawayStatus(giveaway.id, 'ended');

            // Mesajı güncelle
            await this.finishGiveawayWithWinners(giveaway, winners, automatic);

            this.logger.logGiveaway('sonlandı', giveaway.id, {
                winners: winners,
                participantCount: participants.length,
                automatic: automatic
            });

            return { success: true, winners: winners };

        } catch (error) {
            this.logger.error('Çekiliş sonlandırılırken hata:', error);
            return { success: false, error: error.message };
        }
    }

    selectWinners(participants, winnersCount) {
        if (participants.length <= winnersCount) {
            return participants.map(p => p.user_id);
        }

        const shuffled = [...participants].sort(() => 0.5 - Math.random());
        return shuffled.slice(0, winnersCount).map(p => p.user_id);
    }

    async finishGiveawayWithWinners(giveaway, winners, automatic) {
        try {
            const channel = await this.client.channels.fetch(giveaway.channel_id);
            const message = await channel.messages.fetch(giveaway.message_id);
            const host = await this.client.users.fetch(giveaway.host_id);

            // Embed'i güncelle
            const embed = this.createGiveawayEmbed({
                title: giveaway.title,
                description: giveaway.description,
                prize: giveaway.prize,
                host: host,
                endTime: giveaway.end_time,
                winnersCount: giveaway.winners_count,
                participantCount: 0,
                requirements: giveaway.requirements ? JSON.parse(giveaway.requirements) : null,
                isEnded: true,
                winners: winners
            });

            const row = this.createGiveawayButtons(false);

            await message.edit({
                embeds: [embed],
                components: [row]
            });

            // Kazanan duyurusunu yap
            const winnerMentions = winners.map(w => `<@${w}>`).join(', ');
            await channel.send({
                content: `🎉 **Çekiliş bitti!** 🎉\n\n**Kazanan${winners.length > 1 ? 'lar' : ''}:** ${winnerMentions}\n**Ödül:** ${giveaway.prize}\n\nTebrikler! ${automatic ? '(Otomatik sonlandırıldı)' : ''}`
            });

        } catch (error) {
            this.logger.error('Çekiliş kazanan mesajı gönderilirken hata:', error);
        }
    }

    async finishGiveawayWithoutWinners(giveaway, automatic) {
        try {
            const channel = await this.client.channels.fetch(giveaway.channel_id);
            const message = await channel.messages.fetch(giveaway.message_id);
            const host = await this.client.users.fetch(giveaway.host_id);

            // Durumu güncelle
            this.database.updateGiveawayStatus(giveaway.id, 'ended');

            // Embed'i güncelle
            const embed = this.createGiveawayEmbed({
                title: giveaway.title,
                description: giveaway.description,
                prize: giveaway.prize,
                host: host,
                endTime: giveaway.end_time,
                winnersCount: giveaway.winners_count,
                participantCount: 0,
                requirements: giveaway.requirements ? JSON.parse(giveaway.requirements) : null,
                isEnded: true,
                winners: null
            });

            const row = this.createGiveawayButtons(false);

            await message.edit({
                embeds: [embed],
                components: [row]
            });

            // Mesaj gönder
            await channel.send({
                content: `😞 **Çekiliş bitti!**\n\n**Ödül:** ${giveaway.prize}\n\nMaalesef hiç katılımcı olmadığı için kazanan seçilemedi! ${automatic ? '(Otomatik sonlandırıldı)' : ''}`
            });

        } catch (error) {
            this.logger.error('Çekiliş kazanansız mesajı gönderilirken hata:', error);
        }
    }

    async cancelGiveaway(messageId) {
        try {
            const giveaway = this.database.getGiveaway(messageId);
            
            if (!giveaway || giveaway.status !== 'active') {
                return { success: false, error: 'Çekiliş bulunamadı veya zaten sonlanmış!' };
            }

            // Durumu güncelle
            this.database.updateGiveawayStatus(giveaway.id, 'cancelled');

            const channel = await this.client.channels.fetch(giveaway.channel_id);
            const message = await channel.messages.fetch(giveaway.message_id);
            const host = await this.client.users.fetch(giveaway.host_id);

            // Embed'i güncelle
            const embed = new EmbedBuilder()
                .setTitle('❌ Çekiliş İptal Edildi!')
                .setDescription(
                    `**Ödül:** ${giveaway.prize}\n\n` +
                    (giveaway.description ? `${giveaway.description}\n\n` : '') +
                    '**Bu çekiliş iptal edilmiştir!**'
                )
                .setColor(parseInt(process.env.EMBED_COLOR_ERROR, 16) || 0xFF0000)
                .setFooter({
                    text: `Düzenleyen: ${host.username}`,
                    iconURL: host.displayAvatarURL()
                })
                .setTimestamp();

            const row = this.createGiveawayButtons(false);

            await message.edit({
                embeds: [embed],
                components: [row]
            });

            await channel.send({
                content: `❌ **Çekiliş iptal edildi!**\n\n**Ödül:** ${giveaway.prize}\n\nBu çekiliş yönetici tarafından iptal edilmiştir.`
            });

            this.logger.logGiveaway('iptal edildi', giveaway.id);

            return { success: true };

        } catch (error) {
            this.logger.error('Çekiliş iptal edilirken hata:', error);
            return { success: false, error: error.message };
        }
    }

    stop() {
        if (this.checkInterval) {
            clearInterval(this.checkInterval);
            this.logger.info('Çekiliş otomatik kontrol sistemi durduruldu');
        }
    }
}

module.exports = { GiveawayManager };